#include "BookFunctions.h"

void addBookToVector(std::vector<Book>& vec_of_books)
{
	Book new_book;
	std::cout << "Enter the title of the book: ";
	new_book.book_name = defence_title();
	std::cout << "Enter the author of the book: ";
	new_book.book_author = defence2();
	std::cout << "Enter the year of publication of the book: ";
	new_book.year_issue = defence_time(1800, 2022);
	std::cout << "Enter the index of the book: ";
	new_book.index = defence_index();
	vec_of_books.push_back(new_book);
}
void writeEndFileBooks(std::vector<Book>& vec_of_books)
{
	std::ofstream fadd(FILE_OF_BOOKS, std::ios::app);
	fadd << std::endl;
	fadd << vec_of_books.at(vec_of_books.size() - 1).book_name << ";"
		<< vec_of_books.at(vec_of_books.size() - 1).book_author << ";" << vec_of_books.at(vec_of_books.size() - 1).year_issue << ";"
		<< vec_of_books.at(vec_of_books.size() - 1).index;
}
std::vector<std::string> split(const std::string& str, const std::string& delim)
{
	std::vector<std::string> tokens;
	size_t prev = 0, pos = 0;
	do
	{
		pos = str.find(delim, prev);
		if (pos == std::string::npos) pos = str.length();
		std::string token = str.substr(prev, pos - prev);
		if (!token.empty()) tokens.push_back(token);
		prev = pos + delim.length();
	} while (pos < str.length() && prev < str.length());
	return tokens;
}
Book initializeBook(std::string str)
{
	std::vector<std::string> values = split(str, ";");
	Book result = { values[0], values[1], std::stoi(values[2]), std::stoi(values[3]) };
	return result;
}
void readFileBook(std::vector<Book>& vec_of_books)
{
	std::ifstream read(FILE_OF_BOOKS, std::ios::in); 
	if (!read.is_open())
	{
		std::ofstream ofs(FILE_OF_BOOKS);
		ofs.close();
	}
	else
	{
		std::string str;
		while (std::getline(read, str))
		{
			if (str == "")
			{
				continue;
			}
			Book temp = initializeBook(str);
			vec_of_books.push_back(temp);
		}
	}
	read.close();
}

int editBook(std::vector<Book>& vec_of_books)
{
	int choice, choice1, index, new_year_issue;
	std::string new_book_name, new_book_author;
	showBookArray(vec_of_books);
	std::cout << "\nEnter the index of the book you want to change: " << std::endl;
	index = defence3(vec_of_books.size() + 1);
	std::cout << "Are you sure you want to change this book?" << std::endl;
	std::cout << " 1 - Yes || 0 - No " << std::endl;
	std::cout << " Your choice: " << std::endl;
	choice = defence(2);
	if (choice == 0)
	{
		return 0;
	}
	system("cls");
	if (choice == 1)
	{
		std::cout << "===================================" << std::endl;
		std::cout << "~~~~What do you want to change?~~~~" << std::endl;
		std::cout << " 1 - Title " << std::endl;
		std::cout << " 2 - Author" << std::endl;
		std::cout << " 3 - Year of issue" << std::endl;
		std::cout << " 0 - Back" << std::endl;
		std::cout << "===================================" << std::endl;
		choice1 = defence(4);
		if (choice1 == 1) {
			std::cout << "Enter the title of the book - ";
			new_book_name = defence_title();
			vec_of_books.at(index - 1).book_name = new_book_name;
			std::cout << vec_of_books.size();
			writeBookVector(vec_of_books);
		}
		if (choice1 == 2) {
			std::cout << "Enter the author of the book - ";
			new_book_author = defence2();
			vec_of_books.at(index - 1).book_author = new_book_author;
			std::cout << vec_of_books.size();
			writeBookVector(vec_of_books);
		}
		if (choice1 == 3) {
			std::cout << "Enter the year of publication of the book - ";
			new_year_issue = defence_time(1800, 2021);
			vec_of_books.at(index - 1).year_issue = new_year_issue;
			std::cout << vec_of_books.size();
			writeBookVector(vec_of_books);
		}
		if (choice1 == 0)
		{
			return 0;
		}
		if (choice1 != 0)
		{
			showBookArray(vec_of_books);
		}
	}
}
int deleteBook(std::vector<Book>& vec_of_books)
{
	int delete_position, choice;
	showBookArray(vec_of_books);
	std::cout << "\n Enter the index of the book you want to delete: " << std::endl;
	delete_position = defence3(vec_of_books.size() + 1); 
	system("cls");
	std::cout << "Are you sure you want to delete this book?" << std::endl;
	std::cout << " 1 - Yes || 0 - No " << std::endl;
	std::cout << " Your choice: " << std::endl;
	choice = defence(2);
	if (choice == 0)
	{
		return 0;
	}
	if (choice == 1)
	{
		system("cls");
		vec_of_books.erase(vec_of_books.begin() + delete_position - 1); 
		delete_position++;
		std::cout << vec_of_books.size();
		writeBookVector(vec_of_books);
	}
}
void writeBookVector(std::vector<Book>& vec_of_book)
{
	std::ofstream fout(FILE_OF_BOOKS, std::ios::out);
	fout << std::endl;
	for (int i = 0; i < vec_of_book.size(); i++)
	{
		if (i < vec_of_book.size())
		{
			fout << std::endl;
		}
		fout << vec_of_book.at(i).book_name << ";" << vec_of_book.at(i).book_author << ";" << vec_of_book.at(i).year_issue << ";" << vec_of_book.at(i).index;
	}
	fout.close();
}
void showBookArray(std::vector <Book>& vec_of_books)
{
	std::cout << "=================================================================" << std::endl;
	std::cout << "|       Title       |     Author    |  Year of issue  |  Index  |" << std::endl;
	std::cout << "=================================================================" << std::endl;
	for (int i = 0; i < vec_of_books.size(); i++)
	{
		std::cout << vec_of_books.at(i).book_name << " | " << vec_of_books.at(i).book_author << " | " << vec_of_books.at(i).year_issue << " | " << vec_of_books.at(i).index << std::endl;
		std::cout << "=================================================================" << std::endl;
	}
	std::cout << "\n0 - Back " << std::endl;
	system("pause");
}