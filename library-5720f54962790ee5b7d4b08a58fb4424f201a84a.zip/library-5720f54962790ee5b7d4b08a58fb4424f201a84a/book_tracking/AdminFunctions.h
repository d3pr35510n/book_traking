#pragma once
#include "Main.h"
void adminFunction(std::vector<Account>& vec_of_accounts, std::vector<Book>& vec_of_books);
void adminMenu();
void viewMenu();
void addMenu();
void editMenu();
void deleteMenu();