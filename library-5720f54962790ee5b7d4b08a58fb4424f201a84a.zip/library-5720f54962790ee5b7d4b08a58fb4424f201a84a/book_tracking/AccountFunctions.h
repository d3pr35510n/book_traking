#pragma once
#include "Main.h"
void writeEndFileAccounts(std::vector <Account>& vec_of_accounts);
void readFileAccounts(std::vector <Account>& vec_of_accounts);
void createAdminAccount(std::vector<Account>& vec_of_accounts);
