#include "AdminFunctions.h"

void adminFunction(std::vector<Account>& vec_of_accounts, std::vector<Book>& vec_of_books)
{
	system("Color C0");
	while (true) 
	{
		int choice, choice1, choice2, choice3, choice4;
		system("cls");
		adminMenu();
		choice = defence(5);
		system("cls");
		if (choice == 1) {
			while (true)
			{
				system("cls");
				viewMenu();
				choice1 = defence(2);
				if (choice1 == 1)
				{
					showBookArray(vec_of_books);
				}
				if (choice1 == 0)
				{
					break;
				}
			}
		}
		if (choice == 2) {
			while (true) {
				system("cls");
				addMenu();
				choice2 = defence(2);
				if (choice2 == 1)
				{
					addBookToVector(vec_of_books);
					writeEndFileBooks(vec_of_books);
					showBookArray(vec_of_books);
				}
				if (choice2 == 0)
				{
					break;
				}
			}
		}
		if (choice == 3) {
			while (true) {
				system("cls");
				editMenu();
				choice3 = defence(2);
				if (choice3 == 1)
				{
					editBook(vec_of_books);
				}
				if (choice3 == 0)
				{
					break;
				}
			}
		}
		if (choice == 4) {
			while (true) {
				system("cls");
				deleteMenu();
				choice4 = defence(2);
				if (choice4 == 1)
				{
					deleteBook(vec_of_books);
				}

				if (choice4 == 0)
				{
					break;
				}
			}
		}
		if (choice == 0)
		{
			authorisation(vec_of_accounts, vec_of_books);
		}
	}
}
void adminMenu()
{
	std::cout << "======================================" << std::endl;
	std::cout << "~~~~~~~~Administrator functions~~~~~~~" << std::endl;
	std::cout << " 1 - View all books " << std::endl;
	std::cout << " 2 - Adding a book " << std::endl;
	std::cout << " 3 - Editing a book " << std::endl;
	std::cout << " 4 - Deleting a book " << std::endl;
	std::cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" << std::endl;
	std::cout << " 0 - Back " << std::endl;
	std::cout << "======================================" << std::endl;
	std::cout << " Your choice: ";
}

void viewMenu()
{

	std::cout << "============================================" << std::endl;
	std::cout << "~~~~~~~~~~~~~~~~View all books~~~~~~~~~~~~~~" << std::endl;
	std::cout << " 1 - Do you want to see a list of all books? " << std::endl;
	std::cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" << std::endl;
	std::cout << " 0 - Back " << std::endl;
	std::cout << "============================================" << std::endl;
	std::cout << " Your choice: ";
}
void addMenu()
{

	std::cout << "===============================" << std::endl;
	std::cout << "~~~~~~~~~Adding a book~~~~~~~~~" << std::endl;
	std::cout << " 1 - Do you want to add a book?" << std::endl;
	std::cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" << std::endl;
	std::cout << " 0 - Back " << std::endl;
	std::cout << "===============================" << std::endl;
	std::cout << " Your choice: ";
}
void editMenu()
{
	std::cout << "===================================" << std::endl;
	std::cout << "~~~~~~~~~~~Editing a book~~~~~~~~~~" << std::endl;
	std::cout << " 1 - Do you want to edit a book?" << std::endl;
	std::cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" << std::endl;
	std::cout << " 0 - Back " << std::endl;
	std::cout << "===================================" << std::endl;
	std::cout << " Your choice: ";
}
void deleteMenu()
{
	std::cout << "====================================" << std::endl;
	std::cout << "~~~~~~~~~~~Deleting a book~~~~~~~~~~" << std::endl;
	std::cout << " 1 - Do you want to delete the book?" << std::endl;
	std::cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" << std::endl;
	std::cout << " 0 - Back " << std::endl;
	std::cout << "====================================" << std::endl;
	std::cout << " Your choice: ";
}