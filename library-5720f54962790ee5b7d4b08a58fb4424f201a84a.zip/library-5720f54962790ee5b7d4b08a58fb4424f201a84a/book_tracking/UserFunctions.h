#pragma once
#include "Main.h"
void userFunction(std::vector<Account>& vec_of_accounts, std::vector<Book>& vec_of_books);
void returnFunction();
void userMenu();
void registrationMenu();