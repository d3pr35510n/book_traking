#include "UserFunctions.h"
void userFunction(std::vector<Account>& vec_of_accounts, std::vector<Book>& vec_of_books)
{
	system("Color 90");
	while (true) {
		int choice, choice1, choice3, choice4;
		system("cls");
		userMenu();
		choice = defence(3);
		if (choice == 1)
		{
			while (true)
			{
				system("cls");
				viewMenu();
				choice1 = defence(2);
				if (choice1 == 1)
				{
					showBookArray(vec_of_books);
				}
				if (choice1 == 0)
				{
					break;
				}
			}
		}
		if (choice == 2)
		{
			system("cls");
			viewMenu();
			choice4 = defence(2);
			if (choice4 == 1)
			{
				showBookArray(vec_of_books);
				std::cout << "Enter the index of the book you want to order: ";
				int index, time;
				std::string full_name, day_of_birth, month_of_birth, year_of_birth, number;
				index = defence_exist_index();
				system("cls");
				std::cout << "Enter your full name: ";
				full_name = defence2();
				std::cout << "Enter your day of birth: ";
				day_of_birth = defence_time(0, 32);
				std::cout << "Enter your month of birth: ";
				month_of_birth = defence_time(0, 13);
				std::cout << "Enter your year of birth: ";
				year_of_birth = defence_time(1919, 2016);
				std::cout << "Enter your phone number: 8(029)" ;
				number = defence_phone_number();
				system("cls");
				std::cout << "Enter the number of days for which you borrow the book: ";
				time = defence_time(1, 91);
				system("cls");
				returnFunction();
				choice3 = defence(2);
				if (choice3 == 1)
				{
					userFunction(vec_of_accounts, vec_of_books);
				}
				if(choice3 == 0)
				{
					system("pause");
				}
			}
		}
		if (choice == 0)
		{
			authorisation(vec_of_accounts, vec_of_books);
		}
	}
}
void returnFunction()
{
	std::cout << "==========================================" << std::endl;
	std::cout << "~~~~~~~~~~The book is registrated~~~~~~~~~" << std::endl;
	std::cout << "==========================================" << std::endl;
	std::cout << " Want to go back to the custom menu?" << std::endl;
	std::cout << " 1 - Yes || 0 - No " << std::endl;
	std::cout << "==========================================" << std::endl;
	std::cout << "Your choice: ";
}
void userMenu()
{
	std::cout << "============================" << std::endl;
	std::cout << "~~~~~~~User functions~~~~~~~" << std::endl;
	std::cout << " 1 - View all books " << std::endl;
	std::cout << " 2 - Registration of book " << std::endl;
	std::cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~" << std::endl;
	std::cout << " 0 - Back " << std::endl;
	std::cout << "============================" << std::endl;
	std::cout << "Your choice: ";
}
void registrationMenu()
{
	std::cout << "======================================" << std::endl;
	std::cout << "~~~~~~~~~~~Book registration~~~~~~~~~~" << std::endl;
	std::cout << " 1 - Do you want to registrate a book?" << std::endl;
	std::cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" << std::endl;
	std::cout << " 0 - Back " << std::endl;
	std::cout << "======================================" << std::endl;
	std::cout << "Your choice: ";
}