﻿#include "Main.h"

std::vector<Book>vec_of_books;
std::vector <Account>vec_of_accounts;

void main()
{
	system("cls");
	setlocale(LC_ALL, "Russian");
	std::cout << "=============================" << std::endl;
	std::cout << "~~~~~~~~~~Welcome!~~~~~~~~~~~" << std::endl;
	createAdminAccount(vec_of_accounts);
	readFileAccounts(vec_of_accounts);
	readFileBook(vec_of_books);
	authorisation(vec_of_accounts, vec_of_books);
}


void authorisation(std::vector<Account>& vec_of_accounts, std::vector<Book>& vec_of_books)
{
	system("Color E0");
	std::string login, password;
	int choice;
	std::cout << "=============================" << std::endl;
	std::cout << " Do you want to register? " << std::endl;
	std::cout << " 1 - Yes || 0 - No " << std::endl;
	std::cout << "=============================" << std::endl;
	choice = defence(2);
	if (choice == 1)
	{
		std::string login, password;
		int role;
		while (true)
		{
			std::cout << "Enter login - ";
			login = defence_login_password();
			std::cout << "Enter password - ";
			password = defence_login_password();
			system("cls");
			std::cout << "================================" << std::endl;
			std::cout << "~~~~~~~~~~~Enter role~~~~~~~~~~~" << std::endl;
			std::cout << " 1 - User || 2 - Administrator " << std::endl;
			std::cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" << std::endl;
			std::cout << " 0 - Back " << std::endl;
			std::cout << "================================" << std::endl;
			std::cout << " Your choice: ";
			role = defence(3);
			if (role == 1)
			{
				userFunction(vec_of_accounts, vec_of_books);
			}
			if (role == 2)
			{
				adminFunction(vec_of_accounts, vec_of_books);
			}
			if (role == 0)
			{
				authorisation(vec_of_accounts, vec_of_books);
			}
		}
	}
	if (choice == 0)
	{
		system("pause");
	}
}
bool check_string(std::string str)
{
	for (int i = 0; i != str.length(); ++i)
	{
		if (!(int(str[i]) > 31 && int(str[i]) < 33 || int(str[i]) > 64 && int(str[i]) < 91 || int(str[i]) > 96 && int(str[i]) < 123))
		{
			return false;
		}
	}
	return true;
}

bool check_title(std::string str)
{
	for (int i = 0; i != str.length(); ++i)
	{
		if (int(str[i]) < 48 || int(str[i]) > 57 && int(str[i]) < 65 || int(str[i]) > 90 && int(str[i]) < 97 || int(str[i]) > 122)
		{
			return false;
		}
	}
	return true;
}
bool check_login_password(std::string str)
{
	for (int i = 0; i != str.length(); ++i)
	{
		if (int(str[i]) < 65 || int(str[i]) > 90 && int(str[i]) < 97 || int(str[i]) > 122 || str.length() < 7 || str.length() > 15)
		{
			return false;
		}
	}
	return true;
}
bool check_date(std::string str)
{
	for (int i = 0; i != str.length(); ++i)
	{
		if (!(int(str[i]) > 45 && int(str[i]) < 57))
		{
			return false;
		}
	}
	return true;
}
bool check_phone_number(std::string str)
{
	for (int i = 0; i != str.length(); ++i)
	{
		if (!(int(str[i]) > 47 && int(str[i]) < 58 && str.length() == 7))
		{
			return false;
		}
	}
	return true;
}
std::string defence_phone_number()
{
	while (true)
	{
		std::string str;
		std::cin >> str;
		if (std::cin.get() == '\n')
		{
			if (check_phone_number(str))
			{
				system("cls");
				return(str);
			}
			std::cout << "=============================" << std::endl;
			std::cout << " Invalid entry " << std::endl;
			std::cout << " Try again " << std::endl;
			std::cout << "=============================" << std::endl;
		}
		else
		{
			std::cin.clear();
			std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
			std::cout << "=============================" << std::endl;
			std::cout << " Invalid entry " << std::endl;
			std::cout << " Try again " << std::endl;
			std::cout << "=============================" << std::endl;
		}
	}
	system("pause");
	system("cls");
}
std::string defence_login_password()
{
	while (true)
	{
		std::string str;
		std::cin >> str;
		if (std::cin.get() == '\n')
		{
			if (check_login_password(str))
			{
				system("cls");
				return(str);
			}
			std::cout << "========================================================================================================================" << std::endl;
			std::cout << " Invalid entry " << std::endl;
			std::cout << " Try again " << std::endl;
			std::cout << " Login and password should not contain Russian characters, punctuation marks, be less than 7 characters and more than 15";
			std::cout << "========================================================================================================================" << std::endl;
		}
		else
		{
			std::cin.clear();
			std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
			std::cout << "=============================" << std::endl;
			std::cout << " Invalid entry " << std::endl;
			std::cout << " Try again " << std::endl;
			std::cout << "=============================" << std::endl;
		}
	}
	system("pause");
	system("cls");
}
std::string defence_date()
{
	while (true)
	{
		std::string str;
		std::cin >> str;
		if (std::cin.get() == '\n')
		{
			if (check_date(str))
			{
				system("cls");
				return(str);
			}
			std::cout << "=============================" << std::endl;
			std::cout << " Invalid entry " << std::endl;
			std::cout << " Try again " << std::endl;
			std::cout << "=============================" << std::endl;
		}
		else
		{
			std::cin.clear();
			std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
			std::cout << "=============================" << std::endl;
			std::cout << " Invalid entry " << std::endl;
			std::cout << " Try again " << std::endl;
			std::cout << "=============================" << std::endl;
		}
	}
	system("pause");
	system("cls");
}
std::string defence_title()
{
	while (true)
	{
		std::string str;
		std::getline(std::cin, str);
		if (check_title(str))
		{
			system("cls");
			return(str);
		}
		else {
			std::cin.clear();
			//std::cin.ignore();
			std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
			std::cout << "=============================" << std::endl;
			std::cout << " Invalid entry " << std::endl;
			std::cout << " Try again " << std::endl;
			std::cout << "=============================" << std::endl;
		}
	}
	system("pause");
	system("cls");
}
std::string defence2()
{
	while (true)
	{
		std::string str;
		std::getline(std::cin, str);
		if (check_string(str))
		{
			system("cls");
			return(str);
		}
		else {
			std::cin.clear();
			//std::cin.ignore();
			std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
			std::cout << "=============================" << std::endl;
			std::cout << " Invalid entry " << std::endl;
			std::cout << " Try again " << std::endl;
			std::cout << "=============================" << std::endl;
		}
	}
	system("pause");
	system("cls");
}
int defence_time(int first, int second)
{
	while (true)
	{
		int time;
		std::cin >> time;
		if (std::cin.get() == '\n')
		{
			if (time > first && time < second)
			{
				system("cls");
				return(time);
			}
			std::cout << "=============================" << std::endl;
			std::cout << " Invalid entry " << std::endl;
			std::cout << " Try again " << std::endl;
			std::cout << "=============================" << std::endl;
		}
		else
		{
			std::cin.clear();
			std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
			std::cout << "=============================" << std::endl;
			std::cout << " Invalid entry " << std::endl;
			std::cout << " Try again " << std::endl;
			std::cout << "=============================" << std::endl;
		}
	}
	system("pause");
	system("cls");
}
int defence(int limit)
{
	while (true)
	{
		int choice;
		std::cin >> choice;
		if (std::cin.get() == '\n')
		{
			if (choice < limit && choice >= 0)
			{
				system("cls");
				return(choice);
			}
			std::cout << "=============================" << std::endl;
			std::cout << " Invalid entry " << std::endl;
			std::cout << " Try again " << std::endl;
			std::cout << "=============================" << std::endl;
		}
		else
		{
			std::cin.clear();
			std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
			std::cout << "=============================" << std::endl;
			std::cout << " Invalid entry " << std::endl;
			std::cout << " Try again " << std::endl;
			std::cout << "=============================" << std::endl;
		}
	}
	system("pause");
	system("cls");
}
bool check_exist_index(int index)
{ 
	for (int i = 0; i != vec_of_books.size(); ++i)
	{
		if (index == vec_of_books[i].index)
		{
			return true;
		}

	}
	return false;
}
int defence_exist_index()
{
	while (true)
	{
		int index;
		std::cin >> index;
		if (std::cin.get() == '\n')
		{
			if (check_exist_index(index) == true)
			{
				system("cls");
				return(index);
			}
			std::cout << "=============================" << std::endl;
			std::cout << " Invalid entry " << std::endl;
			std::cout << " Try again " << std::endl;
			std::cout << "=============================" << std::endl;
		}
		else
		{
			std::cin.clear();
			std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
			std::cout << "=============================" << std::endl;
			std::cout << " Invalid entry " << std::endl;
			std::cout << " Try again " << std::endl;
			std::cout << "=============================" << std::endl;
		}
	}
	system("pause");
	system("cls");
}
bool check_index(int index)
{
	for (int i = 0; i != vec_of_books.size(); ++i)
	{
		if (index == vec_of_books.at(i).index)
		{
			return false;
		}
	}
	return true;
}
int defence_index()
{
	while (true)
	{
		int index;
		std::cin >> index;
		if (std::cin.get() == '\n')
		{
			if (check_index(index))
			{
				system("cls");
				return(index);
			}
			std::cout << "=============================" << std::endl;
			std::cout << " Invalid entry " << std::endl;
			std::cout << " Try again " << std::endl;
			std::cout << "=============================" << std::endl;
		}
		else
		{
			std::cin.clear();
			std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
			std::cout << "=============================" << std::endl;
			std::cout << " Invalid entry " << std::endl;
			std::cout << " Try again " << std::endl;
			std::cout << "=============================" << std::endl;
		}
	}
	system("pause");
	system("cls");
}
int defence3(int limit)
{
	while (true)
	{
		int choice;
		std::cin >> choice;
		if (std::cin.get() == '\n')
		{
			if (choice <= limit && choice >= 0)
			{
				system("cls");
				return(choice);
			}
			std::cout << "=============================" << std::endl;
			std::cout << " Invalid entry " << std::endl;
			std::cout << " Try again " << std::endl;
			std::cout << "=============================" << std::endl;
		}
		else
		{
			std::cin.clear();
			std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
			std::cout << "=============================" << std::endl;
			std::cout << " Invalid entry " << std::endl;
			std::cout << " Try again " << std::endl;
			std::cout << "=============================" << std::endl;
		}

	}
	system("pause");
	system("cls");
}
void clearVectors(std::vector<Account>& vec_of_accounts, std::vector<Book>& vec_of_books)
{
	vec_of_books.clear();
	vec_of_accounts.clear();
}