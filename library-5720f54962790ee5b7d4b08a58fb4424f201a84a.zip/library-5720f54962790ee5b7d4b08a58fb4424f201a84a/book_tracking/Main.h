#pragma once
#include "Libraries.h"
#include "AccountFunctions.h"
#include "BookFunctions.h"
#include "UserFunctions.h"
#include "AdminFunctions.h"

void main();
bool check_string(std::string str);
void authorisation(std::vector<Account>& vec_of_accounts, std::vector<Book>& vec_of_books);
int defence(int limit);
int defence3(int limit);
int defence_index();
int defence_exist_index();
int defence_time(int first, int second);
bool check_date(std::string str);
bool check_string(std::string str);
bool check_phone_number(std::string str);
bool check_login_password(std::string str);
bool check_title(std::string str);
bool check_index(int index);
bool check_exist_index(int index);
std::string defence_login_password();
std::string defence2();
std::string defence_title();
std::string defence_date();
std::string defence_phone_number();
bool check_date(std::string str);
void clearVectors(std::vector<Account>& vec_of_accounts, std::vector<Book>& vec_of_books);