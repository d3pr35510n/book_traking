#pragma once
#include "Main.h"
void addBookToVector(std::vector<Book>& vec_of_books);
void writeEndFileBooks(std::vector<Book>& vec_of_books); 
void readFileBook(std::vector<Book>& vec_of_books);
int editBook(std::vector<Book>& vec_of_books);
int deleteBook(std::vector<Book>& vec_of_books);
void writeBookVector(std::vector<Book>& vec_of_book);
void showBookArray(std::vector <Book>& vec_of_books);