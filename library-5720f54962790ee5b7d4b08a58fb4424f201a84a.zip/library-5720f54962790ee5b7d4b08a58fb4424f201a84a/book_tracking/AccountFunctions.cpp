#include "AccountFunctions.h"
void writeEndFileAccounts(std::vector <Account>& vec_of_accounts)
{
	std::ofstream fadd(FILE_OF_DATA, std::ios::app);  
	fadd << std::endl;
	fadd << vec_of_accounts.at(vec_of_accounts.size() - 1).login << " "
		<< vec_of_accounts.at(vec_of_accounts.size() - 1).password << " "
		<< vec_of_accounts.at(vec_of_accounts.size() - 1).role;
	fadd.close();
}
void readFileAccounts(std::vector <Account>& vec_of_accounts)
{
	std::ifstream read(FILE_OF_DATA, std::ios::in); 
	if (!read.is_open()) 
		std::cout << "There are no such files" << std::endl;
	else
	{
		Account account_temp;
		while (!read.eof())
		{
			read >> account_temp.login >> account_temp.password >> account_temp.role;
			vec_of_accounts.push_back(account_temp);
		}
	}
	read.close(); 
}
void createAdminAccount(std::vector <Account>& vec_of_accounts)
{
	std::ifstream read(FILE_OF_DATA, std::ios::in); 
	if (!read.is_open()) {
		std::ofstream ofs(FILE_OF_DATA);
		Account account_admin;
		account_admin.login = "admin";
		account_admin.password = "admin";
		account_admin.role = 1;
		vec_of_accounts.push_back(account_admin);
		writeEndFileAccounts(vec_of_accounts);
		vec_of_accounts.clear();
	}
	read.close(); 
}