#pragma once
#include <iostream>
#include <fstream>
#include <algorithm>
#define NOMINMAX
#include <Windows.h>
#include <string>
#include <cstdlib>
#include <cstdio>
#include <vector>
#include <iomanip>
struct Account
{
	std::string login;
	std::string password;
	int role;
};
struct Book
{
	std::string book_name;
	std::string book_author;
	int year_issue; 
	int index;
};

const std::string FILE_OF_DATA = "D:\\Accounts.txt";

const std::string FILE_OF_BOOKS = "D:\\Books.txt";
